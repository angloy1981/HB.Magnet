# signalr-vue
## 简介

该项目基于 ASP.NET Core 2.2 + Vue3，采用前后端分离，进行signalr功能演示

UI 则是目前流行的基于 Vue.js 的 iView



## 主要功能

- 公共聊天

  ![public](signalr-vue-demo/src/assets/public.png)

- 个人聊天

  ![private](signalr-vue-demo/src/assets/private.png)

- 群组聊天

  ![group](signalr-vue-demo/src/assets/group.png)

- 上下线提醒

- 加退群提醒

- 新消息红点提醒